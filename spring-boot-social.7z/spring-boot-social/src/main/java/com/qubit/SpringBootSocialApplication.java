package com.qubit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSocialApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSocialApplication.class, args);
	}
}
